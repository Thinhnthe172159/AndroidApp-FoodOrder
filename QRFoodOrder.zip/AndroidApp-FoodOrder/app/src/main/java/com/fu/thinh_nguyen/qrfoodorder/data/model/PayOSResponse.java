package com.fu.thinh_nguyen.qrfoodorder.data.model;

public class PayOSResponse {
    private String checkoutUrl;

    public String getCheckoutUrl() {
        return checkoutUrl;
    }

    public void setCheckoutUrl(String checkoutUrl) {
        this.checkoutUrl = checkoutUrl;
    }
}

